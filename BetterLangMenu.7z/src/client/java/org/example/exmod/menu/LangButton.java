package org.example.exmod.menu;

import finalforeach.cosmicreach.ui.widgets.CRButton;

public class LangButton extends CRButton {

    public LangButton(String text) {
        super(text);
    }

    public void updateText(){
    }

}
