package org.example.exmod.menu;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.TextureData;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.IntMap;
import com.badlogic.gdx.utils.ScreenUtils;
import finalforeach.cosmicreach.CosmicReachFont;
import finalforeach.cosmicreach.FontTexture;
import finalforeach.cosmicreach.GameAssetLoader;
import finalforeach.cosmicreach.gamestates.GameState;
import finalforeach.cosmicreach.gamestates.MainMenu;
import finalforeach.cosmicreach.lang.Lang;
import finalforeach.cosmicreach.ui.GameStyles;
import finalforeach.cosmicreach.ui.widgets.CRButton;
import org.example.exmod.LangMore;
import org.example.exmod.mixins.FontTextureMixin;

import java.util.Map;

import static finalforeach.cosmicreach.FontTexture.allFontTextures;

public class NewLanguagesMenu extends GameState {

    TextField searchBar;
    ScrollPane langListScrollPane;
    boolean searchBarFocused = false;
    Array<Lang> Langs;
    Table langButtonsTable = new Table();
    private String oldSearch = "";
    private float oldScrollPos = 0;

    public void updateAllText(Array<Actor> actors){
        for (Actor actor : actors){
            if (actor instanceof LangButton langButton) {
                langButton.updateText();
            } else if (actor instanceof Table table) {
                updateAllText(table.getChildren());
            } else if (actor instanceof ScrollPane scrollPane) {
                updateAllText(scrollPane.getChildren());
            }
        }
    }

    public void updateAllText(){
        updateAllText(this.stage.getActors());
    }

    public void setupLangList() {
        String searchText = this.searchBar.getText();
        this.langButtonsTable.clear();

        int i = 0;
        for (Lang lang : this.Langs) {
            String langName = lang.getName();
            if (searchText == null || searchText.isEmpty() || langName.toLowerCase().contains(searchText.toLowerCase())) {
                CRButton selectLangButton = new LangButton(langName) {
                    public void onClick() {
                        lang.select();
                        updateAllText();

                        reloadAllBlocks(); //here

                        refresh();
                    }

                    @Override
                    public void updateText() {
                        super.updateText();
                        this.enabledColor = lang.isCurrentLanguage() ? Color.GOLD : Color.WHITE;
                    }
                };
                selectLangButton.enabledColor = lang.isCurrentLanguage() ? Color.GOLD : Color.WHITE;
                this.langButtonsTable.add(selectLangButton).width(250.0F).height(50.0F).pad(16.0F);
                if (i >= 2){
                    this.langButtonsTable.row();
                    i = 0;
                } else {
                    i++;
                }
            }
        }

    }

    public static void reloadAllBlocks() {
        for (IntMap.Entry<FontTexture> entry : allFontTextures.entries()) {
            FontTexture block = entry.value;
            if (block == null) continue;

            int unicodeStart = block.unicodeStart;
            String fileName;

            switch (unicodeStart) {
                case 0 -> fileName = "cosmic-reach-font-0000-basic.png";
                case 256 -> fileName = "cosmic-reach-font-0100-extended-A.png";
                case 512 -> fileName = "cosmic-reach-font-0200.png";
                case 768 -> fileName = "cosmic-reach-font-0300-diacritics-greek-coptic.png";
                case 1024 -> fileName = "cosmic-reach-font-0400-cyrillic.png";
                case 12288 -> fileName = "cosmic-reach-font-3000-kana.png";
                default -> fileName = "cosmic-reach-font-" +
                        Integer.toHexString(unicodeStart).toUpperCase() + ".png";
            }

            LangMore lang =  (LangMore) Lang.currentLang;
            Map<String , String> fontOverride = lang.getFontOverride();
            fileName = fontOverride.getOrDefault(fileName, fileName);

            FileHandle fontFile = GameAssetLoader.loadAsset("font/" + fileName);
            if (fontFile == null) {
                System.err.println("Missing font file for unicodeStart=" + unicodeStart + " (" + fileName + ")");
                continue;
            } //what am i sending you?


            // --- Begin live-safe reload logic ---
            Texture newTex = new Texture(fontFile);
            int numCols = 16;
            int numRows = 16;
            TextureRegion[][] splitRegions = TextureRegion.split(
                    newTex,
                    newTex.getWidth() / numCols,
                    newTex.getHeight() / numRows
            );

            TextureRegion[] newRegions = new TextureRegion[numCols * numRows];
            Vector2[] newCharStart = new Vector2[newRegions.length];
            Vector2[] newCharSizes = new Vector2[newRegions.length];

            TextureData texData = newTex.getTextureData();
            texData.prepare();
            Pixmap pix = texData.consumePixmap();

            for (int i = 0; i < numCols; i++) {
                for (int j = 0; j < numRows; j++) {
                    int idx = j * numCols + i;
                    TextureRegion texReg = splitRegions[j][i];

                    int maxX = texReg.getRegionX();
                    int maxY = texReg.getRegionY();
                    int minX = texReg.getRegionX() + texReg.getRegionWidth();
                    int minY = texReg.getRegionY() + texReg.getRegionHeight();
                    boolean fullyTransparent = true;

                    for (int px = texReg.getRegionX(); px < texReg.getRegionX() + texReg.getRegionWidth(); px++) {
                        for (int py = texReg.getRegionY(); py < texReg.getRegionY() + texReg.getRegionHeight(); py++) {
                            int pixColor = pix.getPixel(px, py);
                            if ((pixColor & 255) != 0) {
                                minX = Math.min(minX, px);
                                minY = Math.min(minY, py);
                                maxX = Math.max(maxX, px);
                                maxY = Math.max(maxY, py);
                                fullyTransparent = false;
                            }
                        }
                    }

                    newRegions[idx] = new TextureRegion(texReg);
                    newRegions[idx].flip(false, true);

                    newCharStart[idx] = new Vector2(fullyTransparent ? texReg.getRegionX() : minX,
                            fullyTransparent ? texReg.getRegionY() : minY);
                    newCharSizes[idx] = new Vector2(fullyTransparent ? texReg.getRegionWidth() : maxX - minX + 1,
                            fullyTransparent ? texReg.getRegionHeight() : maxY - minY + 1);
                }
            }

            pix.dispose();

            // Dispose old texture safely
            if (block.fontTexture != null) block.fontTexture.dispose();

            // Atomically replace old arrays with new ones
            block.fontTexture = newTex;
            block.fontTextureRegions = newRegions;
            block.fontCharStartPos = newCharStart;
            block.fontCharSizes = newCharSizes;
            // --- End live-safe reload logic ---
        }

        // Rebuild the combined font atlas after all blocks are reloaded
        CosmicReachFont.setAllFontsDirty();
        System.out.println("Reloaded all font blocks safely.");
    }



    public void refresh(){
        this.stage.clear();
        Table layoutTable = new Table();
        layoutTable.setFillParent(true);
        if (this.searchBar != null) this.oldSearch = this.searchBar.getText();
        this.searchBar = new TextField(oldSearch, GameStyles.textstyle);

        EventListener listener = event -> {
            if (event instanceof InputEvent inputEvent) {
                switch (inputEvent.getType()) {
                    case enter:
                        searchBarFocused = true;
                        break;
                    case exit:
                        searchBarFocused = false;
                        break;
                    case keyUp:
                        if (inputEvent.getKeyCode() == 111 || inputEvent.getKeyCode() == 66 && stage.getKeyboardFocus() == searchBar) {
                            stage.setKeyboardFocus(null);
                            searchBarFocused = false;
                        }
                        break;
                    case keyTyped:
                        stage.setKeyboardFocus(searchBar);
                        setupLangList();
                        break;
                    case touchDown:
                        stage.setKeyboardFocus(searchBar);
                        searchBarFocused = true;
                        return true;
                }
            }

            return false;
        };

        this.searchBar.setMessageText(Lang.get("langSelectionSearch"));
        this.searchBar.setAlignment(1);
        this.searchBar.addListener(listener);
        layoutTable.add(this.searchBar).height(50.0F).width(500.0F).top().pad(16.0F);
        layoutTable.row();

        this.setupLangList();

        if (this.langListScrollPane != null) this.oldScrollPos = this.langListScrollPane.getScrollY();
        this.langListScrollPane = new ScrollPane(this.langButtonsTable);

        this.langListScrollPane.layout(); // this is needed but why it is needed is only know to the devil <- Ollie agrees
        this.langListScrollPane.setScrollingDisabled(true, false);
        this.langListScrollPane.setScrollY(this.oldScrollPos);
        this.langListScrollPane.updateVisualScroll();

        //We tried to get a scrollbar but libgdx is a bastard and we couldn't figure it out sry :P

        layoutTable.add(this.langListScrollPane).expand().fill();
        stage.setScrollFocus(this.langListScrollPane);


        Table table = new Table();
        table.setTouchable(Touchable.childrenOnly); //hold up, wait a minute, Ollie does not approve
        table.setRound(true);
        CRButton returnButton = new LangButton(Lang.get("Return_to_Main_Menu")) {
            @Override
            public void onClick() {
                super.onClick();
                GameState.switchToGameState(new MainMenu());
            }

            @Override
            public void updateText() {
                setText(Lang.get("Return_to_Main_Menu"));
            }
        };
        table.add(returnButton).expand().bottom().pad(16.0F).size(250.0F, 50.0F);
        layoutTable.row();
        layoutTable.add(table);
        this.stage.addActor(layoutTable);
    }


    public void create() {
        super.create();
        this.stage.clear();
        Lang.loadLanguages(true);
        this.Langs = Lang.getLanguages();

        refresh();

        Gdx.input.setInputProcessor(this.stage);
    }

    public void switchAwayTo(GameState gameState) {
        super.switchAwayTo(gameState);
        Gdx.input.setInputProcessor(null);
    }

    public void onSwitchTo() {
        super.onSwitchTo();
        Gdx.input.setInputProcessor(this.stage);
    }

    public void render() {
        super.render();
        this.stage.act();
        ScreenUtils.clear(0.145F, 0.078F, 0.153F, 1.0F, true);
        Gdx.gl.glEnable(3042);
        Gdx.gl.glBlendFunc(770, 771);
        Gdx.gl.glDepthFunc(513);
        Gdx.gl.glEnable(2929);
        Gdx.gl.glDisable(2884);
        this.stage.draw();
        Gdx.gl.glCullFace(1029);
        Gdx.gl.glEnable(2884);
        if (Gdx.input.isButtonPressed(0) && !this.searchBarFocused && this.stage.getKeyboardFocus() == this.searchBar) {
            this.stage.setKeyboardFocus(null);
            this.searchBarFocused = false;
        }

    }
}

