package org.example.exmod;

public class ExampleMod {
}
